'''
REQUIRES Python 3+
NOTE: I have only tested this on Windows 2000, Windows XP, and Windows 7.

PySync

license: GPL v2.0
http://www.gnu.org/licenses/gpl-2.0.html

winter@faulk.me
http://faulk.me

~---~--~-~--~-~~-~-~-------~-~------~---~---~-~--~----~-~------~----~-~-~--~--~~

USAGE:
-s : --source-dir        Source directory, copy from directory.
-d : --destination-dir   Destination directory, copy to directory.
-l : --log-file-name     Name of the log file (default: pysync.log)
-n : --no-pause          Do not show pause message when the script is
                         done running.
-r : --remove            Remove files/folders from the destination dir
                         that have been removed from the source dir.
-h : --help              This print out.

pysync.py -s c:\source_dir -d d:\destination_dir -l c:\logs\pysync.log -r -n

'''

import sys, os, filecmp, shutil, time, re
from optparse import OptionParser
from code import InteractiveInterpreter, InteractiveConsole
from datetime import datetime, date, time

# List all dir in a path.
def list_dirs(d):
    dl = []
    for root, dirs, files in os.walk(d):
        for dir_name in dirs:
            dl.append(os.path.join(root, dir_name))
    return dl

# Compares source dir with destination dir and creates a list of changes.
def list_changes(src, dst):
    cls()
    print("Compering "+str(src)+" with "+str(dst))
    try:
        cd = filecmp.dircmp(src, dst)
        if len(cd.funny_files) > 0 or len(cd.left_only) > 0 or len(cd.right_only) > 0 or len(cd.diff_files) > 0:
            rslt = (0, cd.left_only, cd.right_only, cd.diff_files)
        else:
            rslt = (1, [], [], [])
    except:
        rslt = (99, [], [], [])
    return rslt

# Removes all files/folders from the destination that do not exist in the source.
def del_sync(src, dst, del_list):
    i = 0
    num = len(del_list)
    for f in del_list:
        i = i+1
        dst_file = os.path.join(dst,f)

        cls()
        print("Removing: "+str(dst_file))
        if(os.path.isdir(dst_file)):
            try:
                shutil.rmtree(dst_file)
            except:
                log("DelError::"+str(dst_file))
                print("Error removing: "+str(dst_file))
                return 99
        else:
            try:
                os.remove(dst_file)
            except:
                log("DelError::"+str(dst_file))
                print("Error removing: "+str(dst_file))
                return 99
        log("Removed::"+str(dst_file))
        print("Removed "+str(i)+" of "+str(num))

# Syncs all changed and new files and folders.
def sync(src, dst, new_list):
    i = 0
    num = len(new_list)
    for f in new_list:
        i = i+1
        src_file = os.path.join(src,f)
        dst_file = os.path.join(dst,f)

        cls()
        print("Copying: "+str(src_file)+" --> "+str(dst_file))
        if os.path.isdir(src_file) == True:
            try:
                # Copys the files from the source to the destination.
                shutil.copytree(src_file, dst_file)
            except:
                log("CopyError::"+str(src_file))
                print("Error copying: "+str(src_file))
                return 99
        elif os.path.isfile(src_file) == True:
            try:
                # Copys the files from the source to the destination.
                shutil.copy2(src_file, dst_file)
            except:
                log("CopyError::"+str(src_file))
                print("Error copying: "+str(src_file))
                return 99
        log("Copied::"+str(src_file))
        print(str(i)+" of "+str(num)+" synced.")

def init_sync(src_dir, dst_dir):
    # List all diff between src and dst.
    cmp_list = list_changes(src_dir, dst_dir)

    # Based on error code run something.
    if cmp_list[0] == 0:
        change_list = cmp_list[1]+cmp_list[3]
        sync(src_dir, dst_dir, change_list) # Syncs both changed and new files.
        if REMOVEFILES == True:
            print("Removing deleted files from "+str(dst_dir))
            del_sync(src_dir, dst_dir, cmp_list[2]) # Removes all files that are only on the right.
    elif cmp_list[0] == 1:
        print(str(src_dir)+" -- No Change")
        log("NoChange::"+str(src_dir))
    elif cmp_list[0] == 99:
        print("There was an error with the fallowing paths.\nSrc DIR: "+str(src_dir)+"\nDst DIR: "+str(dst_dir))


# Clear the term screen.
def cls():
    if os.name == "posix":
        # Unix/Linux/MacOS/BSD/etc
        os.system('clear')
    elif os.name in ("nt", "dos", "ce"):
        # DOS/Windows
        os.system('CLS')
    else:
        # Fallback for other operating systems.
        numlines = 100
        print('\n' * numlines)

def log(output, t=True):
    dump = os.getcwd()+'\\'+LOGFILE
    try:
        f = open(dump, 'a')
        l = []
        l.append(output)
        if t == False:
            f.write((" - ".join(l))+"\n")
        else:
            f.write(str(datetime.now())+"::"+(" - ".join(l))+"\n")
        f.close()
    except:
        print("Error appending log file.")
        append_error = True

#*****************************************************************#
def main():
    global LOGFILE
    global PAUSE
    global REMOVEFILES
    
    usage="%prog -s source-dir -d destination-dir (-l log-file-name, -r, -n)"
    
    parser = OptionParser(usage=usage)
    parser.add_option("-s", "--source-dir", action="store", type="string", dest="SRCDIR", help="Source directory, copy from directory.")
    parser.add_option("-d", "--destination-dir", action="store", type="string", dest="DSTDIR", help="Destination directory, copy to directory.")
    parser.add_option("-l", "--log-file-name", action="store", type="string", dest="LOGFILE", default="pysync.log", help="Name of the log file (default: pysync.log)")
    parser.add_option("-r", "--remove", action="store_true", dest="REMOVEFILES", default=False, help="Remove files/folders from the destination dir that have been removed from the source dir.")
    parser.add_option("-n", "--no-pause", action="store_true", dest="PAUSE", default=False, help="Do not show pause message when the script is done running.")

    (options, args) = parser.parse_args()
    
    LOGFILE = options.LOGFILE
    PAUSE = options.PAUSE
    REMOVEFILES = options.REMOVEFILES
    
    DSTDIR = os.path.join(*os.path.split(options.DSTDIR))
    SRCDIR = os.path.join(*os.path.split(options.SRCDIR))

    if(os.path.exists(DSTDIR) == False): os.mkdir(DSTDIR)

    print("Starting sync between "+str(SRCDIR)+" --> "+str(DSTDIR))
    print(str(datetime.now())+"\n----------------")
    start_time = datetime.now()
    
    log("-------------------------------------------------------------", False)
    log("Note::Starting sync between "+str(SRCDIR)+" --> "+str(DSTDIR))
    #*****************************************************************#    
    src_dir = SRCDIR
    dst_dir = DSTDIR
    init_sync(src_dir, dst_dir)

    # Get list of dir's
    ln = len(src_dir)
    src_dir = list_dirs(src_dir)

    # Copy sub dirs
    for d in src_dir:
        sub = d[ln:]
        dst_path = os.path.join(dst_dir, sub.lstrip("\\"))
        init_sync(d, dst_path)

    log("Note::Sync complete.")
    #*****************************************************************#
    scan_time = str(datetime.now()-start_time)
    log("Note::Time running "+scan_time)
    print("Time running: "+scan_time)
    
    if PAUSE == 0:
        input("Press any key to exit...")

if __name__ == '__main__':    
    sys.exit(main())
